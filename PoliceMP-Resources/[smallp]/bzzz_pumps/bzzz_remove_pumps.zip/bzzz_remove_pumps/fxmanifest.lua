fx_version 'cerulean'
game { 'gta5' }
author 'BzZz'
description 'Remove pumps'
version '1.0.0'



