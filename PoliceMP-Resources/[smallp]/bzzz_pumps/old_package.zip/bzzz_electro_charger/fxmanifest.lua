fx_version 'cerulean'
game { 'gta5' }
author 'BzZz'
description 'Electric charger'
version '1.0.0'


data_file 'DLC_ITYP_REQUEST' 'stream/bzzz_electro_charger_cars.ytyp'









--[[
Installation:
1) Download zip
2) Extract zip and insert to resources folder
3) Add to server.cfg

If you put the props in another folder, you must edit the fxmanifest:
data_file 'DLC_ITYP_REQUEST' 'stream/bzzz_electro_charger_cars.ytyp'
]]--