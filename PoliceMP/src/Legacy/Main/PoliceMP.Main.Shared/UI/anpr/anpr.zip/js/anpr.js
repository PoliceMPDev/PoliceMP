$(function() {
	window.addEventListener('message', function(event) {
			if (event.data.anpr == "on") {
				resetInterface();
				$("body").show();
			} else if (event.data.anpr == "off") {
				resetInterface();
				$("body").hide();
			}
			
			if (event.data.lock_anpr == "on") {
				$("#lock").show();
			} else if (event.data.lock_anpr == "off") {
				$("#lock").hide();
			}
			
			if (event.data.receive_anpr_data == "on") {
				$("#plate").text("test");
				$("#speed").text(event.data.speed + " MPH");
				$("#model").text(event.data.model);
				$("#colour").text(event.data.colour);
				
				$("#time").text(event.date.date);
				
				setBoxSuccess("#mot", event.data.mot);
				setBoxSuccess("#insurance", event.data.insurance);
				setBoxSuccess("#tax", event.data.tax);
				
				setBoxSuccess("#drugs-intel", event.data.drugsintel);
				setBoxSuccess("#weapons-intel", event.data.weaponsintel);
				setBoxSuccess("#fail-to-stop", event.data.failtostop);
				setBoxSuccess("#outstanding-crime", event.data.outstandingcrime);
				
				setBoxSuccess("#stolen", event.data.stolen);
				setBoxSuccess("#written-off", event.data.writtenoff);
				setBoxSuccess("#scrapped", event.data.scrapped);
				setBoxSuccess("#exported", event.data.exported);
			} else if (event.data.receive_anpr_data == "off") {
				resetInterface();
			}
	});
	
	function setBoxSuccess(box, value) {
		if (value == "true" || value == "True" || value == "TRUE") {
			$(box).addClass("list-group-item-success");
			$(box).removeClass("list-group-item-danger");
			$(box).removeClass("list-group-item-dark");
		} else {
			$(box).addClass("list-group-item-danger");
			$(box).removeClass("list-group-item-success");			
			$(box).removeClass("list-group-item-dark");
		}
	}
	
	function setBoxNone(box) {
			$(box).removeClass("list-group-item-success");
			$(box).removeClass("list-group-item-danger");
			$(box).addClass("list-group-item-dark");
	}
	
	function resetInterface() {
		$("#plate").text("");
		$("#speed").text("0 MPH");
		$("#model").text("NO VEHICLE");
		$("#colour").text("N/A");
		
		setBoxNone("#mot");
		setBoxNone("#insurance");
		setBoxNone("#tax");
		
		setBoxNone("#drugs-intel");
		setBoxNone("#weapons-intel");
		setBoxNone("#fail-to-stop");
		setBoxNone("#outstanding-crime");
		
		setBoxNone("#stolen");
		setBoxNone("#written-off");
		setBoxNone("#scrapped");
		setBoxNone("#exported");
		
		$("#lock").hide();
	}
});